extends Node
## Recebe a distancia da TechGlove (sensor ultrassonico na luva) por UDP.
## Formato do pacote: {"distancia": 12.5}   (cm)

const PORTA := 5005
const TEMPO_SEM_DADOS := 1.0      ## sem pacotes por 1 s = luva desconectada

var udp := PacketPeerUDP.new()

var distancia_cm: float = 0.0
var distancia_suave: float = 0.0
var conectado := false            ## so vira true depois do 1o pacote valido
var _ultimo_pacote := -100.0


func _ready() -> void:
	var erro := udp.bind(PORTA, "127.0.0.1")
	if erro == OK:
		print("TechGlove: esperando dados na porta %d..." % PORTA)
	else:
		print("Erro ao abrir a porta %d: %s" % [PORTA, erro])


func _exit_tree() -> void:
	udp.close()


func _process(delta: float) -> void:
	while udp.get_available_packet_count() > 0:
		var mensagem := udp.get_packet().get_string_from_utf8()
		var dados = JSON.parse_string(mensagem)
		if dados is Dictionary and dados.has("distancia"):
			var d := float(dados["distancia"])
			if d > 0.0 and d < 400.0:          # ignora leitura invalida do sensor (0 ou absurda)
				distancia_cm = d
				if not conectado:
					distancia_suave = d        # primeiro pacote: comeca do valor real, nao do 0
				conectado = true
				_ultimo_pacote = Time.get_ticks_msec() / 1000.0

	if conectado and Time.get_ticks_msec() / 1000.0 - _ultimo_pacote > TEMPO_SEM_DADOS:
		conectado = false

	# Suaviza a oscilacao do sensor sem atrasar demais o gesto
	distancia_suave = lerpf(distancia_suave, distancia_cm, minf(delta * 20.0, 1.0))
